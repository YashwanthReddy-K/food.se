var fs = require('fs');
fs.appendFile('sample.txt', `Learn Node FS module \r\n`, (err)=>{
 if (err) throw err;
 console.log('File is Appended successfully.');
})