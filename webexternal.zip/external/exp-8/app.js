const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.static('public'));
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/studentDB');

const Student = mongoose.model('Student', {
    rollNumber: String,
    name: String,
    email: String,
    department: String,
    year: Number
});

app.post('/api/students', async (req, res) => {
    const student = new Student(req.body);
    await student.save();
    res.json(student);
});

app.get('/api/students', async (req, res) => {
    res.json(await Student.find());
});

app.get('/api/students/:rollNumber', async (req, res) => {
    res.json(await Student.findOne({ rollNumber: req.params.rollNumber }));
});

app.put('/api/students/:rollNumber', async (req, res) => {
    res.json(await Student.findOneAndUpdate({ rollNumber: req.params.rollNumber }, req.body, { new: true }));
});

app.delete('/api/students/:rollNumber', async (req, res) => {
    await Student.findOneAndDelete({ rollNumber: req.params.rollNumber });
    res.json({ message: 'Deleted' });
});

app.listen(3000, () => console.log('Server on http://localhost:3000'));
